//   window.alert("I am learning JAVASCRIPT");
//   alert("I am learning YOU");

/*   document.write("I am learning Javascript");
     document.getElementById("root").innerHTML = "I love Learn Code";
     console.log("I am Learning Javascript");
*/


// Entar Your Name

 /* 
     var x;
     x = prompt("Entar Your Name");
     document.write(x);
*/

//Variable
 /*
     var a = 35;
     let b;
     b = 30
     document.write(a+b);
*/


 /*
     var c = 10;
     var d = c;
     document.write(d);
*/

 /*
     var $e = "Borhan Uddin";
     console.log($e);
*/


// Constant Variable Value Use only one, 

 /*
     const z = 30;
     console.log(z);
*/

//Oparetors